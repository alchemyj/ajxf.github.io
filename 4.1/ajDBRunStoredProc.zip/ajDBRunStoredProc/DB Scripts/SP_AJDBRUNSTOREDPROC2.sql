-- --------------------------------------------------------------------------------
-- Routine DDL
-- Note: comments before and after the routine body will not be stored by the server
-- --------------------------------------------------------------------------------
DELIMITER $$
CREATE PROCEDURE `sp_ajdbrunstoredproc2`(p1 INT, p2 INT, out p3 INT)
BEGIN
set p3 = coalesce(p1,0) + coalesce(p2,0);
END$$
DELIMITER ;