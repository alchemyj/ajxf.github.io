-- --------------------------------------------------------------------------------
-- Routine DDL
-- Note: comments before and after the routine body will not be stored by the server
-- --------------------------------------------------------------------------------
DELIMITER $$

CREATE PROCEDURE `sp_ajdbrunstoredproc1` ()
BEGIN
select 1 as column1,2 as column2,3 as column3,4 as column4 
union
select 5 as column1,6 as column2,7 as column3,8 as column4;
END$$
DELIMITER ;