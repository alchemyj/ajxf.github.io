﻿CREATE TABLE `tbl_udf_customer_countrec` (
  `CUSTOMER_NAME` varchar(255) NOT NULL,
  `DOB` date DEFAULT NULL,
  `GENDER` varchar(1) CHARACTER SET latin1 DEFAULT NULL,
  `CUSTOMER_LVL` int DEFAULT NULL,
  `TELEPHONE` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`CUSTOMER_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `aj_usecase`.`tbl_udf_customer_countrec`
(`CUSTOMER_NAME`,
`DOB`,
`GENDER`,
`CUSTOMER_LVL`,
`TELEPHONE`)
VALUES
('CHAN TAI MAN',
str_to_date('1977-01-02', '%Y-%m-%d'),
'M',
5,
'22205555');

INSERT INTO `aj_usecase`.`tbl_udf_customer_countrec`
(`CUSTOMER_NAME`,
`DOB`,
`GENDER`,
`CUSTOMER_LVL`,
`TELEPHONE`)
VALUES
('JERRY SZE',
str_to_date('1988-04-06', '%Y-%m-%d'),
'M',
2,
'22203333');

INSERT INTO `aj_usecase`.`tbl_udf_customer_countrec`
(`CUSTOMER_NAME`,
`DOB`,
`GENDER`,
`CUSTOMER_LVL`,
`TELEPHONE`)
VALUES
('MERRY SO',
str_to_date('1988-03-03', '%Y-%m-%d'),
'F',
4,
'22201111');

INSERT INTO `aj_usecase`.`tbl_udf_customer_countrec`
(`CUSTOMER_NAME`,
`DOB`,
`GENDER`,
`CUSTOMER_LVL`,
`TELEPHONE`)
VALUES
('TOM HUI',
str_to_date('1978-12-03', '%Y-%m-%d'),
'M',
1,
'22204444');

INSERT INTO `aj_usecase`.`tbl_udf_customer_countrec`
(`CUSTOMER_NAME`,
`DOB`,
`GENDER`,
`CUSTOMER_LVL`,
`TELEPHONE`)
VALUES
('VICKY CHAN',
str_to_date('1981-05-12', '%Y-%m-%d'),
'F',
3,
'22202222');

INSERT INTO `aj_usecase`.`tbl_udf_customer_countrec`
(`CUSTOMER_NAME`,
`DOB`,
`GENDER`,
`CUSTOMER_LVL`,
`TELEPHONE`)
VALUES
('EVA LIN',
str_to_date('1989-07-18', '%Y-%m-%d'),
'F',
6,
'22207777');

INSERT INTO `aj_usecase`.`tbl_udf_customer_countrec`
(`CUSTOMER_NAME`,
`DOB`,
`GENDER`,
`CUSTOMER_LVL`,
`TELEPHONE`)
VALUES
('KAREN SHEN',
str_to_date('1983-09-15', '%Y-%m-%d'),
'M',
7,
'22206666');

